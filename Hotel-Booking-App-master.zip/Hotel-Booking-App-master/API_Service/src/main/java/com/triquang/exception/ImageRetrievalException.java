package com.triquang.exception;

public class ImageRetrievalException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ImageRetrievalException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
