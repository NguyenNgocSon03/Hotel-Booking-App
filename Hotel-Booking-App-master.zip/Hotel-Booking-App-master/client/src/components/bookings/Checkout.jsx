import { BookingForm } from './BookingForm'
import React from 'react'

export const Checkout = () => {
  return (
    <div>
        <BookingForm/>
    </div>
  )
}
